

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Carlos leon
 */
public class funciones {
   
    public static String calculadora(String numero1,String numero2,String signo){
    Double resultado=0.0;
    String respuesta;
    
     if(signo.equals("-")){
         resultado=Double.parseDouble(numero1)-Double.parseDouble(numero2);
     }
      if(signo.equals("+")){
         resultado=Double.parseDouble(numero1)+Double.parseDouble(numero2);
     }
       if(signo.equals("*")){
         resultado=Double.parseDouble(numero1)*Double.parseDouble(numero2);
     }
        if(signo.equals("/")){
         resultado=Double.parseDouble(numero1)/Double.parseDouble(numero2);
     }
        respuesta=resultado.toString();
        return respuesta;
}
    public static boolean punto(String cadena){
    boolean resultado;
    resultado=false;
      
        for(int i=0; i<cadena.length(); i++){
            if(cadena.substring(i, i+1).equals(".")){
                resultado=true;
                break;
            }
            
        }
        return resultado;
}
    
}
